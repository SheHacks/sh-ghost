----------------------------
IMAGE DIRECTORY (/img)
----------------------------

This directory should contain all images used throughout the site.
Images within the root are used by css as background images.

----------------------------
SUB DIRECTORIES
----------------------------

All other images to within logical sub-directories related to the section of the site they appear in. Maintaining this structure is optionally but recommended.

All editable Photoshop files (psd) can be found in the assets.zip directory in the download bundle.
